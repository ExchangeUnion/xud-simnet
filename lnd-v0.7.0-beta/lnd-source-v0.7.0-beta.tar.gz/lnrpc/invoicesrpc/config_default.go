// +build !invoicesrpc

package invoicesrpc

// Config is empty for non-invoicesrpc builds.
type Config struct{}
