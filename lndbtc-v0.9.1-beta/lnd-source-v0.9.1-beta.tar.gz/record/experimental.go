package record

const (
	// KeySendType is the custom record identifier for keysend preimages.
	KeySendType uint64 = 5482373484
)
