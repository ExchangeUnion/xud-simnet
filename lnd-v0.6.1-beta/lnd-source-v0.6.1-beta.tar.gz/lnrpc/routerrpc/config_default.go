// +build !routerrpc

package routerrpc

// Config is the default config for the package. When the build tag isn't
// specified, then we output a blank config.
type Config struct{}
